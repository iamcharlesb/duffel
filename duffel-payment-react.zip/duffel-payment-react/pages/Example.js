import { CardPayment } from '@duffel/components'
import '@duffel/components/dist/CardPayment.min.css'

const successfulPaymentHandlerFn = () => {
  alert('yay!')
}

const errorPaymentHandlerFn = (error) => {
  alert('nay!')
}

export const Example = () => (
  <CardPayment
    duffelPaymentIntentClientToken={'eyJjbGllbnRfc2VjcmV0IjoicGlfM0xEbHBVQWcySmhFeTh2WTBXTUxPZ1NuX3NlY3JldF9VREpvNm1uVTZLV05JaGVzRkJyNGxVOTNLIiwicHVibGlzaGFibGVfa2V5IjoicGtfdGVzdF9EQUJLY0E2Vzh6OTc0cTdPSWY0YmJ2MVQwMEpwRmMyOUpWIn0='}
    successfulPaymentHandler={successfulPaymentHandlerFn}
    errorPaymentHandler={errorPaymentHandlerFn}
  />
)